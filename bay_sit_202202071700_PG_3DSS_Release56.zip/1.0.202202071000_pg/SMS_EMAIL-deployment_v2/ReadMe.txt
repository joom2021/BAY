Deployment details

1. Copy paste merAdd2.jsp file at [..WebContent\eng\admin\merProfile]

2. Copy paste B2cSendMail.class file at [..classes\b2c]

3. Copy paste SendMail.class, SendSMS.class at [..classes\b2c\util]

4. Delete Email.properties from [..\wen-inf\classes]

5. Copy paste EmailSms.properties file at [..\wen-inf\classes]
