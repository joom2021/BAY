Deployment details



1. Copy paste B2cSendMail.class file at [..classes\b2c]

2. Copy paste SendMail.class, SendSMS.class at [..classes\b2c\util]


