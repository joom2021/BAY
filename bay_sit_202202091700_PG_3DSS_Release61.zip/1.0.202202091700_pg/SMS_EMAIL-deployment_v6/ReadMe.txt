Deployment details


1. Delete EmailSms.properties from [..\wen-inf\classes]

2. Copy paste Email.properties file at [..\wen-inf\classes]

